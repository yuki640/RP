export let hero = {
    id: null,
    name: "",
    image: null,
    vie: 0,
    attaque: 0,
    defense: 0,
    mana: 0,
    inventaire: [],
    lieuxVisites: [],
};

console.log("hero", hero);
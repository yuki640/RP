function initCombat() {
    console.log("Le combat commence !");
    // Logique de combat à implémenter
}
